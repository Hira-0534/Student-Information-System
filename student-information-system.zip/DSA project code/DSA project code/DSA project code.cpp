#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;
// Define the structure for Student Information
struct Student {
    int rollNo;
    string name;
    string courseCode;
    int marks;
    float cgpa;
};

// Define the structure for Linked List Node
struct Node {
    Student student;
    Node* next;
};

// Function to display the student information
void displayStudent(const Student& s) {
    cout << "Roll No: " << s.rollNo << ", Name: " << s.name
        << ", Course Code: " << s.courseCode << ", Marks: "
        << s.marks << ", CGPA: " << s.cgpa << endl;
}

// Function to check if roll number is unique in the array
bool isRollNoUnique(const vector<Student>& students, int rollNo) {
    for (const auto& student : students) {
        if (student.rollNo == rollNo) {
            return false; // Roll No already exists
        }
    }
    return true;
}

// Operations for ADT Array
void insertStudentToArray(vector<Student>& students) {
    Student newStudent;
    cout << "Enter Roll No: ";
    cin >> newStudent.rollNo;

    // Check if the roll number is unique
    if (!isRollNoUnique(students, newStudent.rollNo)) {
        cout << "Error: Roll No already exists!\n";
        return;
    }

    cout << "Enter Name: ";
    cin >> newStudent.name;  
    cout << "Enter Course Code: ";
    cin >> newStudent.courseCode;  
    cout << "Enter Marks: ";
    cin >> newStudent.marks;
    cout << "Enter CGPA: ";
    cin >> newStudent.cgpa;

    students.push_back(newStudent);
    cout << "Student added\n";
}

void displayArray(const vector<Student>& students) {
    for (const auto& student : students) {
        displayStudent(student);
    }
}

void searchByCourse(const vector<Student>& students) {
    string course;
    cout << "Enter Course Code to search: ";
    cin >> course;
    bool found = false;
    for (const auto& student : students) {
        if (student.courseCode == course) {
            displayStudent(student);
            found = true;
        }
    }
    if (!found) {
        cout << "No student found with Course Code: " << course << endl;
    }
}

void searchByCGPA(const vector<Student>& students) {
    float cgpa;
    cout << "Enter CGPA to search: ";
    cin >> cgpa;
    bool found = false;
    for (const auto& student : students) {
        if (student.cgpa >= cgpa) {
            displayStudent(student);
            found = true;
        }
    }
    if (!found) {
        cout << "No student found with CGPA >= " << cgpa << endl;
    }
}

void searchByMarks(const vector<Student>& students) {
    int marks;
    cout << "Enter Marks to search: ";
    cin >> marks;
    bool found = false;
    for (const auto& student : students) {
        if (student.marks >= marks) {
            displayStudent(student);
            found = true;
        }
    }
    if (!found) {
        cout << "No student found with Marks >= " << marks << endl;
    }
}

void deleteByRollNo(vector<Student>& students) {
    int rollNo;
    cout << "Enter Roll No to delete: ";
    cin >> rollNo;

    auto it = find_if(students.begin(), students.end(), [rollNo](const Student& s) {
        return s.rollNo == rollNo;
        });

    if (it != students.end()) {
        students.erase(it);
        cout << "Student with Roll No " << rollNo << " deleted.\n";
    }
    else {
        cout << "Error: No student found with Roll No " << rollNo << "!\n";
    }
}

// Operations for Linked List
void insertAtBeginning(Node*& head) {
    Student newStudent;
    cout << "Enter Roll No: ";
    cin >> newStudent.rollNo;
    cout << "Enter Name: ";
    cin >> newStudent.name;  // Changed to use cin for single word input
    cout << "Enter Course Code: ";
    cin >> newStudent.courseCode;  // Changed to use cin for single word input
    cout << "Enter Marks: ";
    cin >> newStudent.marks;
    cout << "Enter CGPA: ";
    cin >> newStudent.cgpa;

    Node* newNode = new Node{ newStudent, head };
    head = newNode;
}

void insertAfterNode(Node* head) {
    int rollNo;
    cout << "Enter Roll No after which you want to insert: ";
    cin >> rollNo;

    Node* current = head;
    while (current != nullptr && current->student.rollNo != rollNo) {
        current = current->next;
    }

    if (current != nullptr) {
        Student newStudent;
        cout << "Enter Roll No: ";
        cin >> newStudent.rollNo;
        cout << "Enter Name: ";
        cin >> newStudent.name;  
        cout << "Enter Course Code: ";
        cin >> newStudent.courseCode;  
        cout << "Enter Marks: ";
        cin >> newStudent.marks;
        cout << "Enter CGPA: ";
        cin >> newStudent.cgpa;

        Node* newNode = new Node{ newStudent, current->next };
        current->next = newNode;
    }
    else {
        cout << "Roll No not found!\n";
    }
}

void insertSorted(Node*& head) {
    Student newStudent;
    cout << "Enter Roll No: ";
    cin >> newStudent.rollNo;
    cout << "Enter Name: ";
    cin >> newStudent.name;  
    cout << "Enter Course Code: ";
    cin >> newStudent.courseCode;  
    cout << "Enter Marks: ";
    cin >> newStudent.marks;
    cout << "Enter CGPA: ";
    cin >> newStudent.cgpa;

    Node* newNode = new Node{ newStudent, nullptr };
    if (head == nullptr || head->student.rollNo >= newStudent.rollNo) {
        newNode->next = head;
        head = newNode;
    }
    else {
        Node* current = head;
        while (current->next != nullptr && current->next->student.rollNo < newStudent.rollNo) {
            current = current->next;
        }
        newNode->next = current->next;
        current->next = newNode;
    }
}

void displayLinkedList(Node* head) {
    Node* current = head;
    if (current == nullptr) {
        cout << "No students in the list.\n";
        return;
    }
    while (current != nullptr) {
        displayStudent(current->student);
        current = current->next;
    }
}

void searchInLinkedList(Node* head) {
    int rollNo;
    cout << "Enter Roll No to search: ";
    cin >> rollNo;
    Node* current = head;
    bool found = false;
    while (current != nullptr) {
        if (current->student.rollNo == rollNo) {
            displayStudent(current->student);
            found = true;
            break;
        }
        current = current->next;
    }
    if (!found) {
        cout << "Student with Roll No: " << rollNo << " not found.\n";
    }
}

void deleteAfterNode(Node* head) {
    int rollNo;
    cout << "Enter Roll No after which you want to delete: ";
    cin >> rollNo;

    Node* current = head;
    while (current != nullptr && current->student.rollNo != rollNo) {
        current = current->next;
    }

    if (current != nullptr && current->next != nullptr) {
        Node* temp = current->next;
        current->next = current->next->next;
        delete temp;
    }
    else {
        cout << "Cannot delete, no node found after the specified Roll No.\n";
    }
}

void bubbleSortLinkedList(Node* head) {
    if (!head) return;
    bool swapped;
    do {
        swapped = false;
        Node* current = head;
        while (current && current->next) {
            if (current->student.rollNo > current->next->student.rollNo) {
                swap(current->student, current->next->student);
                swapped = true;
            }
            current = current->next;
        }
    } while (swapped);
}

void deleteLinkedList(Node*& head) {
    Node* current = head;
    while (current != nullptr) {
        Node* nextNode = current->next;
        delete current;
        current = nextNode;
    }
    head = nullptr;
}

// Main function
int main() {
    cout<<" * *********** student information system*********:";
    vector<Student> students;
    Node* head = nullptr;
    int choice;

    do {
        cout << "\nMenu:\n";
        cout << "1. ADT Array Operations\n";
        cout << "2. Linked List Operations\n";
        cout << "3. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1: { // ADT Array Operations
            int arrayChoice;
            do {
                cout << "\nADT Array Menu:\n";
                cout << "1. Insert Student\n";
                cout << "2. Display Students\n";
                cout << "3. Search by Course\n";
                cout << "4. Search by CGPA\n";
                cout << "5. Search by Marks\n";
                cout << "6. Delete Student by Roll No\n";
                cout << "7. Go back\n";
                cout << "Enter your choice: ";
                cin >> arrayChoice;

                switch (arrayChoice) {
                case 1: insertStudentToArray(students); break;
                case 2: displayArray(students); break;
                case 3: searchByCourse(students); break;
                case 4: searchByCGPA(students); break;
                case 5: searchByMarks(students); break;
                case 6: deleteByRollNo(students); break;
                }
            } while (arrayChoice != 7);
            break;
        }
        case 2: { // Linked List Operations
            int listChoice;
            do {
                cout << "\nLinked List Menu:\n";
                cout << "1. Insert at Beginning\n";
                cout << "2. Insert After Node\n";
                cout << "3. Insert Sorted\n";
                cout << "4. Display Students\n";
                cout << "5. Search by Roll No\n";
                cout << "6. Delete After Node\n";
                cout << "7. Bubble Sort Linked List\n";
                cout << "8. Go back\n";
                cout << "Enter your choice: ";
                cin >> listChoice;

                switch (listChoice) {
                case 1: insertAtBeginning(head); break;
                case 2: insertAfterNode(head); break;
                case 3: insertSorted(head); break;
                case 4: displayLinkedList(head); break;
                case 5: searchInLinkedList(head); break;
                case 6: deleteAfterNode(head); break;
                case 7: bubbleSortLinkedList(head); break;
                }
            } while (listChoice != 8);
            break;
        }
        case 3:
            cout << "Exiting...\n";
            deleteLinkedList(head);  // Cleanup linked list memory before exit
            break;
        default:
            cout << "Invalid choice! Try again.\n";
        }
    } while (choice != 3);

    return 0;
}
